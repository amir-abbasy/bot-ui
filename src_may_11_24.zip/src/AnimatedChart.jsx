import React, { useRef, useEffect } from "react";

const CustomCandlestickChart = ({ data }) => {
  const canvasRef = useRef(null);
  const animationRef = useRef(null);
  const candleWidth = 10; // Width of each candlestick
  const spacing = 15; // Spacing between each candlestick

  const drawFrame = (index) => {
    if (!canvasRef.current || !data || index >= data.length) {
      cancelAnimationFrame(animationRef.current);
      return;
    }

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");

    // Clear the canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw all candles up to the current index
    for (let i = 0; i <= index; i++) {

      const candle = data[i];
    console.log(candle);

      const high = candle.h;
      const low = candle.l;
      const open = candle.o;
      const close = candle.c;

      ctx.strokeStyle = open > close ? "red" : "green";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(i * (candleWidth + spacing) + 10, high);
      ctx.lineTo(i * (candleWidth + spacing) + 10, low);
      ctx.stroke();
      ctx.fillRect(i * (candleWidth + spacing), Math.min(open, close), candleWidth, Math.abs(open - close));
    }

    // Schedule the next frame
    animationRef.current = requestAnimationFrame(() => drawFrame(index + 1));
  };

  useEffect(() => {
    animationRef.current = requestAnimationFrame(() => drawFrame(0));

    return () => cancelAnimationFrame(animationRef.current);
  }, [data]);

  return (
    <canvas
      ref={canvasRef}
      width={window.innerWidth * 20}
      height={window.innerHeight}
    />
  );
};

export default CustomCandlestickChart;
