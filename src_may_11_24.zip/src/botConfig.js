// BTC/USDT
let botConfig = {
  S_R_Area: 30, // 100%
  leftValue: 100,
  rightValue: 100,

  leftValueSmall: 16, //4h
  rightValueSmall: 16, //4h

  targetLoose: 0.5,

  // BTC
  // initialResist: 29574,
  // initialSupport: 29374,

  // data
  initialResist: 30150,
  initialSupport: 29599,

  // data_
  // initialResist: 29500,
  // initialSupport: 29100,

  // data3
  // initialResist: 26500.82,
  // initialSupport: 25800.82,

  initalRangeStart: 40,
  padding: 100,
  candleWidth: 7,
  test: {},
};

export default botConfig;
