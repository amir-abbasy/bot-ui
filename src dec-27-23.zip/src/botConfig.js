// BTC/USDT
let botConfig = {
  S_R_Area:  40, // 100%
  leftValue: 100,
  rightValue: 100,

  leftValueSmall: 10,
  rightValueSmall: 10,

// BTC
  // initialResist: 29574,
  // initialSupport: 29374,

  

  // data
  initialResist: 30150,
  initialSupport: 29599,

  // data_
  // initialResist: 29500,
  // initialSupport: 29100,

  // data3
  // initialResist: 26500.82,
  // initialSupport: 25800.82,

  initalRangeStart: 40,
  padding : 100,
  candleWidth : 7,
  test: {},
};

// ETH/USDT
// let botConfig = {
//   S_R_Box_Area: 30, // 100%
//   leftValue: 100,
//   rightValue: 100,

//   leftValueSmall: 10,
//   rightValueSmall: 10,

//   initialResist: 1880,
//   initialSupport: 1855,
//   initalRangeStart: 40,
// };

export default botConfig;
